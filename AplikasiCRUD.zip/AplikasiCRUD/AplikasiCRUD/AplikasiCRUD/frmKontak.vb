﻿Public Class frmKontak

    Sub KosongkanForm()
        txtKode.Text = ""
        txtNama.Text = ""
        txtTelpon.Text = ""
        txtEmail.Text = ""
        txtAlamat.Text = ""
        txtKode.Focus()
    End Sub

    Sub MatikanForm()
        txtKode.Enabled = False
        txtNama.Enabled = False
        cmbKelamin.Enabled = False
        txtTelpon.Enabled = False
        txtEmail.Enabled = False
        txtAlamat.Enabled = False
    End Sub

    Sub HidupkanForm()
        txtKode.Enabled = True
        txtNama.Enabled = True
        cmbKelamin.Enabled = True
        txtTelpon.Enabled = True
        txtEmail.Enabled = True
        txtAlamat.Enabled = True
    End Sub

    Sub TampilkanData()
        Call KoneksiDB()
        DA = New OleDb.OleDbDataAdapter("select * from kontak", CONN)
        DS = New DataSet
        DA.Fill(DS)
        DGV.DataSource = DS.Tables(0)
        DGV.ReadOnly = True


    End Sub

    Private Sub frmKontak_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call MatikanForm()
        Call TampilkanData()
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub btnKeluar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnKeluar.Click
        Me.Close()
    End Sub

    Private Sub btnTambah_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTambah.Click
        Call HidupkanForm()
        Call KosongkanForm()
    End Sub

    Private Sub btnBatal_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBatal.Click
        Call MatikanForm()
        Call KosongkanForm()
    End Sub

    Private Sub btnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSimpan.Click
        If txtKode.Text = "" Or txtNama.Text = "" Or cmbKelamin.Text = "" Then
            MsgBox("Data Belum Lengkap")
            Exit Sub
        Else
            Call KoneksiDB()
            CMD = New OleDb.OleDbCommand("select * from kontak where kode='" & txtKode.Text & "'", CONN)
            DR = CMD.ExecuteReader
            DR.Read()
            If Not DR.HasRows Then
                Call KoneksiDB()
                Dim simpan As String
                simpan = "insert into kontak values('" & txtKode.Text & "','" & txtNama.Text & "','" & cmbKelamin.Text & "','" & txtTelpon.Text & "','" & txtEmail.Text & "','" & txtAlamat.Text & "')"
                CMD = New OleDb.OleDbCommand(simpan, CONN)
                CMD.ExecuteNonQuery()
                MsgBox("Input Sukses")
            Else
                MsgBox(" Kode teman sudah ada ")
            End If

            Call MatikanForm()
            Call KosongkanForm()
            Call TampilkanData()
        End If
    End Sub


    Private Sub DGV_CellMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles DGV.CellMouseClick
        On Error Resume Next
        txtKode.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        txtNama.Text = DGV.Rows(e.RowIndex).Cells(1).Value
        cmbKelamin.Text = DGV.Rows(e.RowIndex).Cells(2).Value
        txtTelpon.Text = DGV.Rows(e.RowIndex).Cells(3).Value
        txtEmail.Text = DGV.Rows(e.RowIndex).Cells(4).Value
        txtAlamat.Text = DGV.Rows(e.RowIndex).Cells(5).Value

        Call HidupkanForm()
        txtKode.Enabled = False
    End Sub

    Private Sub btnEdit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEdit.Click
        If txtKode.Text = "" Or txtNama.Text = "" Or cmbKelamin.Text = "" Then
            MsgBox("Data Belum Lengkap")
            Exit Sub
        Else
            Call KoneksiDB()
            CMD = New OleDb.OleDbCommand("update kontak set nama_teman='" & txtNama.Text & "',jenis_kelamin='" & cmbKelamin.Text & "',no_telp='" & txtTelpon.Text & "',email='" & txtEmail.Text & "',alamat_rumah='" & txtAlamat.Text & "' where kode='" & txtKode.Text & "'", CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Update Data Sukses")
        End If

        Call MatikanForm()
        Call KosongkanForm()
        Call TampilkanData()
    End Sub

    Private Sub btnHapus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHapus.Click
        If txtKode.Text = "" Then
            MsgBox("Tidak ada data yang akan dihapus")
            Exit Sub
        Else
            If MessageBox.Show("Yakin Akan Menghapus?", "Konfirmasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Call KoneksiDB()
                CMD = New OleDb.OleDbCommand("delete from kontak where kode='" & txtKode.Text & "'", CONN)
                CMD.ExecuteNonQuery()
                MsgBox("Hapus Data Sukses")
                Call MatikanForm()
                Call KosongkanForm()
                Call TampilkanData()
            Else
                Call MatikanForm()
                Call KosongkanForm()
            End If
        End If
    End Sub

    Private Sub DGV_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles DGV.CellContentClick

    End Sub
End Class

