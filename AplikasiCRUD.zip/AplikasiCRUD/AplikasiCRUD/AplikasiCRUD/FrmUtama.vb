﻿Public Class FrmUtama

    Private Sub DataTemanToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataTemanToolStripMenuItem.Click
        frmKontak.Show()
    End Sub
End Class