﻿Public Class frmMenuUtama

    Private Sub btnDaftarBaru_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDaftarBaru.Click
        frmDaftar.Show()
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        frmUpdate.Show()
    End Sub
End Class